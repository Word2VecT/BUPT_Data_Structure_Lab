//
// Created by na2co on 2023/9/25.
//

#ifndef LAB_1_COMMON_H
#define LAB_1_COMMON_H

#include <iostream>
#include <fstream>

constexpr int MAX_ID_LENGTH = 15;
constexpr int MAX_NAME_LENGTH = 10;
constexpr int MAX_STUDENT_NUM = 10;
constexpr int STUDENT_NUM = 5;

#endif //LAB_1_COMMON_H